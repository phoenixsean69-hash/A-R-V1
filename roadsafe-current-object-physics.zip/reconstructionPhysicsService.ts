/*
 * [RoadSafe:PhysicsFoundationImportV1]
 */
import {
  ceilSimulationTime,
  normaliseParticipantPhysicsProfile,
  normaliseReconstructionPhysicsSettings,
  normaliseSceneObjectPhysicsProfile,
  quantiseSimulationTime,
} from "../utils/reconstructionPhysicsFoundation";

import {
  usesGeneratedRoad,
  type AccidentReconstruction,
  type MovementPathPoint,
  type CollisionKinematicOutcome,
  type CollisionKinematicsSummary,
  type ParticipantCollisionKinematics,
  type ParticipantPhysicsProfile,
  type PhysicsCollisionEvent,
  type PhysicsCollisionShape,
  type PhysicsSimulationSummary,
  type PhysicsVector2D,
  type ReconstructionPhysicsSettings,
  type ReconstructionPosition,
  type ReconstructionSceneObject,
  type ReconstructionVehicle,
  type SceneObjectPhysicsProfile,
} from "../types/reconstruction";

import {
  clamp,
  getParticipantStateAtTime,
  isPhysicsGeneratedPathPoint,
  sortMovementPathPoints,
  syncLegacyParticipantFields,
} from "../utils/reconstructionGeometry";
import { getReconstructionWorldDimensions } from "../utils/reconstructionWorldScale";
import { createParticipantImpactResponses } from "../utils/reconstructionImpactResponse";
import { getDefaultSceneObjectMassKg } from "../utils/reconstructionPhysicsDefaults";

import {
  angleBetweenDegrees,
  classifyParticipantOutcome,
  distanceAlongPoints,
  estimateAverageForceRangeKn,
  momentumVectorNs,
  normaliseContactDurationRangeMs,
  rotationalKineticEnergyKj,
  roundPhysicsValue,
  subtractVector,
  translationalKineticEnergyKj,
  vectorMagnitude,
} from "../utils/reconstructionKinematics";

import {
  calculatePlanarMomentOfInertia,
  createPhysicsCollisionShape,
  findSweptPhysicsCollision,
  getPhysicsCollisionManifold,
  velocityAtContactPoint,
  type PhysicsCollisionManifold,
  type PhysicsPose2D,
  type PhysicsShapeDimensions,
} from "./physicsCollisionGeometry";

import {
  resolveVelocitySampleWindow,
} from "../utils/reconstructionMotionKinematics";

interface Vector2 {
  x: number;
  y: number;
}

interface ResolvedParticipantPhysicsProfile extends ParticipantPhysicsProfile {
  collisionShape: PhysicsCollisionShape;
  lengthMetres: number;
  widthMetres: number;
  collisionFriction: number;
  momentOfInertiaScale: number;
}

interface ResolvedSceneObjectPhysicsProfile extends SceneObjectPhysicsProfile {
  massKg: number;
  collisionShape: PhysicsCollisionShape;
  lengthMetres: number;
  widthMetres: number;
  collisionFriction: number;
}

interface PhysicsTrajectorySample {
  timeSeconds: number;
  position: Vector2;
  velocity: Vector2;
  angularVelocityDegreesPerSecond: number;
}

interface SimulationBody {
  participant: ReconstructionVehicle;
  profile: ResolvedParticipantPhysicsProfile;
  impactPoint: MovementPathPoint;
  position: Vector2;
  previousPosition: Vector2;
  velocity: Vector2;
  incomingVelocity: Vector2;
  rotation: number;
  previousRotation: number;
  angularVelocityDegreesPerSecond: number;
  timeSeconds: number;
  points: MovementPathPoint[];
  trajectorySamples: PhysicsTrajectorySample[];
  primaryResponseAction?: "Deflect" | "Ricochet";
  primaryResponseLabel?: string;
  stopped: boolean;
  restTimeSeconds?: number;
  collidedWithParticipants: Set<string>;
  collidedWithObjects: Set<string>;
}

interface CollisionParticipantChange {
  participantId: string;

  participantType:
    ReconstructionVehicle["type"];

  massKg: number;
  momentOfInertiaKgM2: number;
  impactPosition: Vector2;
  incomingVelocity: Vector2;
  outgoingVelocity: Vector2;
  incomingAngularVelocityDegreesPerSecond: number;
  outgoingAngularVelocityDegreesPerSecond: number;
  impulseNs: Vector2;
  outcome: CollisionKinematicOutcome;
}

interface CollisionImpulseResult {
  collided: boolean;
  impactEnergyKj: number;
  relativeSpeedKmh: number;
  impactAngleDegrees: number;
  normalImpulseNs: number;
  frictionImpulseNs: number;
  totalImpulseNs: number;
  outcome: CollisionKinematicOutcome;
  participantChanges: CollisionParticipantChange[];
  angularVelocityChangesDegPerSecond: Record<string, number>;
}

interface DetectedParticipantContact {
  timeSeconds: number;
  leftId: string;
  rightId: string;
  leftPosition: Vector2;
  rightPosition: Vector2;
  contactPosition: Vector2;
  normal: Vector2;
}

interface DetectedSceneObjectContact {
  timeSeconds: number;
  participantId: string;
  objectId: string;
  participantPosition: Vector2;
  objectPosition: Vector2;
  contactPosition: Vector2;
  normal: Vector2;
}

function firstContactOnStep(
  leftStart: Vector2,
  leftEnd: Vector2,
  rightStart: Vector2,
  rightEnd: Vector2,
  collisionDistance: number,
): { alpha: number; distance: number } | null {
  const relativeStart = {
    x: rightStart.x - leftStart.x,
    y: rightStart.y - leftStart.y,
  };
  const relativeDelta = {
    x: (rightEnd.x - rightStart.x) - (leftEnd.x - leftStart.x),
    y: (rightEnd.y - rightStart.y) - (leftEnd.y - leftStart.y),
  };
  const radius = Math.max(0, collisionDistance);
  const c = dot(relativeStart, relativeStart) - radius * radius;

  if (c <= 0) {
    return { alpha: 0, distance: magnitude(relativeStart) };
  }

  const a = dot(relativeDelta, relativeDelta);
  if (a < 0.0000001) return null;

  const b = 2 * dot(relativeStart, relativeDelta);
  const discriminant = b * b - 4 * a * c;
  if (discriminant < 0) return null;

  const squareRoot = Math.sqrt(Math.max(0, discriminant));
  const enterAlpha = (-b - squareRoot) / (2 * a);
  const exitAlpha = (-b + squareRoot) / (2 * a);
  const alpha = enterAlpha >= 0 && enterAlpha <= 1
    ? enterAlpha
    : exitAlpha >= 0 && exitAlpha <= 1
      ? exitAlpha
      : null;

  if (alpha === null) return null;

  const separation = {
    x: relativeStart.x + relativeDelta.x * alpha,
    y: relativeStart.y + relativeDelta.y * alpha,
  };
  return { alpha, distance: magnitude(separation) };
}

function participantWorldPositionAtTime(
  participant: ReconstructionVehicle,
  timeSeconds: number,
  width: number,
  height: number,
): Vector2 {
  return worldPosition(
    getParticipantStateAtTime(
      participant,
      timeSeconds,
      {
        widthMetres: width,
        heightMetres: height,
      },
    ).position,
    width,
    height,
  );
}

/*
 * [RoadSafe:BoundarySafeImpactVelocityV1]
 *
 * The final authored impact pose uses a backward finite difference. Interior
 * samples use a centred window and the route start uses a forward window.
 */
function participantVelocityAtTime(
  participant: ReconstructionVehicle,
  timeSeconds: number,
  width: number,
  height: number,
  sampleSeconds: number,
): Vector2 {
  const authoredPoints =
    sortMovementPathPoints(
      participant.pathPoints,
    ).filter(
      (point) =>
        !isPhysicsGeneratedPathPoint(
          point,
        ),
    );

  const firstPathTime =
    authoredPoints[0]
      ?.timeSeconds ??
    0;

  const lastPathTime =
    authoredPoints.at(-1)
      ?.timeSeconds ??
    firstPathTime;

  const sampleWindow =
    resolveVelocitySampleWindow(
      timeSeconds,
      sampleSeconds,
      firstPathTime,
      lastPathTime,
    );

  const before =
    participantWorldPositionAtTime(
      participant,
      sampleWindow.beforeTimeSeconds,
      width,
      height,
    );

  const after =
    participantWorldPositionAtTime(
      participant,
      sampleWindow.afterTimeSeconds,
      width,
      height,
    );

  const elapsed =
    sampleWindow.afterTimeSeconds -
    sampleWindow.beforeTimeSeconds;

  if (
    elapsed >
    0.0001
  ) {
    const sampled = {
      x:
        (
          after.x -
          before.x
        ) /
        elapsed,

      y:
        (
          after.y -
          before.y
        ) /
        elapsed,
    };

    if (
      magnitude(
        sampled,
      ) >
      0.05
    ) {
      /*
       * [RoadSafe:ParticipantPhysicsSpeedOverrideV1]
       * Preserve the authored route direction while applying an explicit
       * solver-speed magnitude when the investigator has supplied one.
       */
      const configuredSpeedKmh =
        participant.physics?.inputSpeedKmh;

      if (
        typeof configuredSpeedKmh === "number" &&
        Number.isFinite(configuredSpeedKmh)
      ) {
        const sampledMagnitude =
          magnitude(sampled);

        const configuredSpeedMps =
          kmhToMps(
            Math.max(
              0,
              configuredSpeedKmh,
            ),
          );

        return sampledMagnitude > 0.0001
          ? {
              x:
                (sampled.x /
                  sampledMagnitude) *
                configuredSpeedMps,
              y:
                (sampled.y /
                  sampledMagnitude) *
                configuredSpeedMps,
            }
          : sampled;
      }

      return sampled;
    }
  }

  const state =
    getParticipantStateAtTime(
      participant,
      timeSeconds,
      {
        widthMetres: width,
        heightMetres: height,
      },
    );

  const speed =
    kmhToMps(
      typeof participant.physics?.inputSpeedKmh === "number" &&
      Number.isFinite(participant.physics.inputSpeedKmh)
        ? Math.max(
            0,
            participant.physics.inputSpeedKmh,
          )
        : state.speedKmh ||
          participant.estimatedSpeedKmh,
    );

  return {
    x:
      Math.cos(
        (
          state.rotation *
          Math.PI
        ) /
          180,
      ) *
      speed,

    y:
      Math.sin(
        (
          state.rotation *
          Math.PI
        ) /
          180,
      ) *
      speed,
  };
}

function resolveParticipantPhysicsProfile(
  participant: ReconstructionVehicle,
): ResolvedParticipantPhysicsProfile {
  return normaliseParticipantPhysicsProfile({
    ...getDefaultParticipantPhysics(
      participant,
    ),
    ...(participant.physics ?? {}),
  }) as ResolvedParticipantPhysicsProfile;
}

function resolveSceneObjectPhysicsProfile(
  object: ReconstructionSceneObject,
): ResolvedSceneObjectPhysicsProfile {
  return normaliseSceneObjectPhysicsProfile({
    ...getDefaultSceneObjectPhysics(
      object,
    ),
    massKg:
      object.physics?.massKg ??
      getDefaultSceneObjectMassKg(
        object.type,
      ),
    ...(object.physics ?? {}),
  }) as ResolvedSceneObjectPhysicsProfile;
}

function participantDimensions(
  profile: ResolvedParticipantPhysicsProfile,
): PhysicsShapeDimensions {
  return {
    collisionShape: profile.collisionShape,
    collisionRadiusMetres: profile.collisionRadiusMetres,
    lengthMetres: profile.lengthMetres,
    widthMetres: profile.widthMetres,
  };
}

function objectDimensions(
  profile: ResolvedSceneObjectPhysicsProfile,
): PhysicsShapeDimensions {
  return {
    collisionShape: profile.collisionShape,
    collisionRadiusMetres: profile.collisionRadiusMetres,
    lengthMetres: profile.lengthMetres,
    widthMetres: profile.widthMetres,
  };
}

function participantPoseAtTime(
  participant: ReconstructionVehicle,
  timeSeconds: number,
  width: number,
  height: number,
): PhysicsPose2D {
  const state =
    getParticipantStateAtTime(
      participant,
      timeSeconds,
      {
        widthMetres: width,
        heightMetres: height,
      },
    );

  return {
    position:
      worldPosition(
        state.position,
        width,
        height,
      ),

    rotationDegrees:
      state.rotation,
  };
}

function bodyPose(body: SimulationBody, previous = false): PhysicsPose2D {
  return {
    position: previous ? body.previousPosition : body.position,
    rotationDegrees: previous ? body.previousRotation : body.rotation,
  };
}

function sceneObjectPose(
  object: ReconstructionSceneObject,
  width: number,
  height: number,
): PhysicsPose2D {
  return {
    position: worldPosition(object.position, width, height),
    rotationDegrees: object.rotation,
  };
}

function physicalCollisionTolerance(
  settings: ReconstructionPhysicsSettings,
): number {
  return clamp(settings.collisionToleranceMetres, 0, 0.35);
}

function detectEarliestParticipantContact(
  participants: ReconstructionVehicle[],
  settings: ReconstructionPhysicsSettings,
  width: number,
  height: number,
  durationSeconds: number,
): DetectedParticipantContact | null {
  if (participants.length < 2) return null;

  const profiles = new Map(
    participants.map((participant) => [
      participant.id,
      resolveParticipantPhysicsProfile(participant),
    ]),
  );
  const step = clamp(Math.min(settings.timeStepSeconds, 0.08), 0.02, 0.08);
  const tolerance = physicalCollisionTolerance(settings);

  for (let time = 0; time < durationSeconds - 0.0001; time += step) {
    const nextTime = Math.min(durationSeconds, time + step);
    let earliestInStep: DetectedParticipantContact | null = null;

    for (let leftIndex = 0; leftIndex < participants.length; leftIndex += 1) {
      for (let rightIndex = leftIndex + 1; rightIndex < participants.length; rightIndex += 1) {
        const left = participants[leftIndex];
        const right = participants[rightIndex];
        const leftProfile = profiles.get(left.id)!;
        const rightProfile = profiles.get(right.id)!;
        const contact = findSweptPhysicsCollision(
          participantPoseAtTime(left, time, width, height),
          participantPoseAtTime(left, nextTime, width, height),
          participantDimensions(leftProfile),
          participantPoseAtTime(right, time, width, height),
          participantPoseAtTime(right, nextTime, width, height),
          participantDimensions(rightProfile),
          tolerance,
        );
        if (!contact) continue;

        const candidate: DetectedParticipantContact = {
          timeSeconds: time + (nextTime - time) * contact.alpha,
          leftId: left.id,
          rightId: right.id,
          leftPosition: contact.leftPose.position,
          rightPosition: contact.rightPose.position,
          contactPosition: contact.manifold.contactPoint,
          normal: contact.manifold.normal,
        };

        if (
          earliestInStep === null ||
          candidate.timeSeconds < earliestInStep.timeSeconds
        ) {
          earliestInStep = candidate;
        }
      }
    }

    if (earliestInStep !== null) return earliestInStep;
  }

  return null;
}

function detectEarliestSceneObjectContact(
  participants: ReconstructionVehicle[],
  sceneObjects: ReconstructionSceneObject[],
  settings: ReconstructionPhysicsSettings,
  width: number,
  height: number,
  durationSeconds: number,
): DetectedSceneObjectContact | null {
  if (participants.length === 0 || sceneObjects.length === 0) return null;

  const participantProfiles = new Map(
    participants.map((participant) => [
      participant.id,
      resolveParticipantPhysicsProfile(participant),
    ]),
  );
  const collidableObjects = sceneObjects
    .map((object) => ({
      object,
      profile: resolveSceneObjectPhysicsProfile(object),
      pose: sceneObjectPose(object, width, height),
    }))
    .filter(({ profile }) => profile.enabled && profile.collidable);

  if (collidableObjects.length === 0) return null;

  const step = clamp(Math.min(settings.timeStepSeconds, 0.08), 0.02, 0.08);
  const tolerance = physicalCollisionTolerance(settings);

  for (let time = 0; time < durationSeconds - 0.0001; time += step) {
    const nextTime = Math.min(durationSeconds, time + step);
    let earliestInStep: DetectedSceneObjectContact | null = null;

    for (const participant of participants) {
      const participantProfile = participantProfiles.get(participant.id)!;
      const participantStart = participantPoseAtTime(participant, time, width, height);
      const participantEnd = participantPoseAtTime(participant, nextTime, width, height);

      for (const { object, profile, pose } of collidableObjects) {
        const contact = findSweptPhysicsCollision(
          participantStart,
          participantEnd,
          participantDimensions(participantProfile),
          pose,
          pose,
          objectDimensions(profile),
          profile.collidable ? tolerance : 0,
        );
        if (!contact) continue;

        const candidate: DetectedSceneObjectContact = {
          timeSeconds: time + (nextTime - time) * contact.alpha,
          participantId: participant.id,
          objectId: object.id,
          participantPosition: contact.leftPose.position,
          objectPosition: contact.rightPose.position,
          contactPosition: contact.manifold.contactPoint,
          normal: contact.manifold.normal,
        };

        if (
          earliestInStep === null ||
          candidate.timeSeconds < earliestInStep.timeSeconds
        ) {
          earliestInStep = candidate;
        }
      }
    }

    if (earliestInStep !== null) return earliestInStep;
  }

  return null;
}

export const DEFAULT_PHYSICS_SETTINGS: ReconstructionPhysicsSettings = {
  enabled: true,
  mode: "Physics After Primary Impact",
  autoRunOnPlay: true,
  liveSimulation: false,
  timeStepSeconds: 0.1,
  collisionToleranceMetres: 0.18,
  globalFrictionMultiplier: 1,
  airDrag: 0.015,
  stopSpeedKmh: 2,
  showVelocityVectors: true,
  showImpactEffects: true,
  replacePostImpactPath: true,
  contactDurationMinimumMs: 80,
  contactDurationMaximumMs: 150,
};

const SOLID_OBJECT_TYPES = new Set([
  "Road Barrier",
  "Guardrail",
  "Wall",
  "Fence",
  "Traffic Light",
  "Street Light",
  "Tree",
  "Parked Vehicle",
  "Bus Stop",
  "Stop Sign",
  "Give Way Sign",
  "Speed Limit Sign",
]);

const SOFT_OBJECT_TYPES = new Set([
  "Fallen Branch",
  "Debris",
  "Vehicle Part",
  "Traffic Cone",
  "Bush",
]);

const LOW_GRIP_OBJECT_TYPES = new Set([
  "Oil Spill",
  "Loose Gravel",
  "Puddle",
]);

function createId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function magnitude(vector: Vector2): number {
  return Math.hypot(vector.x, vector.y);
}

function normalise(vector: Vector2): Vector2 {
  const length = magnitude(vector);
  if (length < 0.0001) return { x: 1, y: 0 };
  return { x: vector.x / length, y: vector.y / length };
}

function dot(left: Vector2, right: Vector2): number {
  return left.x * right.x + left.y * right.y;
}

function cross(left: Vector2, right: Vector2): number {
  return left.x * right.y - left.y * right.x;
}

function angleDifferenceDegrees(from: Vector2, to: Vector2): number {
  if (magnitude(from) < 0.001 || magnitude(to) < 0.001) return 0;
  const start = Math.atan2(from.y, from.x);
  const end = Math.atan2(to.y, to.x);
  return ((((end - start) * 180) / Math.PI + 540) % 360) - 180;
}

function blendRotation(
  current: number,
  target: number,
  amount: number,
): number {
  const difference = ((target - current + 540) % 360) - 180;
  return current + difference * clamp(amount, 0, 1);
}

function rotate(vector: Vector2, degrees: number): Vector2 {
  const radians = (degrees * Math.PI) / 180;
  const cosine = Math.cos(radians);
  const sine = Math.sin(radians);
  return {
    x: vector.x * cosine - vector.y * sine,
    y: vector.x * sine + vector.y * cosine,
  };
}


function deterministicSign(value: string): number {
  let hash = 0;
  for (let index = 0; index < value.length; index += 1) {
    hash = (hash * 31 + value.charCodeAt(index)) | 0;
  }
  return hash % 2 === 0 ? 1 : -1;
}

function kmhToMps(speedKmh: number): number {
  return Math.max(0, speedKmh) / 3.6;
}

function mpsToKmh(speedMps: number): number {
  return Math.max(0, speedMps) * 3.6;
}

function worldPosition(
  position: ReconstructionPosition,
  sceneWidthMetres: number,
  sceneHeightMetres: number,
): Vector2 {
  return {
    x: (position.x / 100) * sceneWidthMetres,
    y: (position.y / 100) * sceneHeightMetres,
  };
}

function scenePosition(
  position: Vector2,
  sceneWidthMetres: number,
  sceneHeightMetres: number,
): ReconstructionPosition {
  return {
    x: clamp((position.x / sceneWidthMetres) * 100, 0, 100),
    y: clamp((position.y / sceneHeightMetres) * 100, 0, 100),
  };
}

function rotationFromVelocity(velocity: Vector2, fallback: number): number {
  if (magnitude(velocity) < 0.05) return fallback;
  return (Math.atan2(velocity.y, velocity.x) * 180) / Math.PI;
}

function getImpactPoint(participant: ReconstructionVehicle): MovementPathPoint {
  const points = sortMovementPathPoints(participant.pathPoints);
  if (points.length === 0) {
    return {
      id: createId("legacy-impact"),
      label: "Primary collision",
      position: participant.collisionPosition,
      timeSeconds: participant.collisionTimeSeconds,
      speedKmh: participant.estimatedSpeedKmh,
      rotation: participant.collisionRotation,
      action: "Impact",
    };
  }
  return (
    points.find((point) => point.action === "Impact") ??
    points.reduce((closest, point) =>
      Math.abs(point.timeSeconds - participant.collisionTimeSeconds) <
      Math.abs(closest.timeSeconds - participant.collisionTimeSeconds)
        ? point
        : closest,
    )
  );
}

function groundSurfaceFriction(
  surface: AccidentReconstruction["scene"]["groundSurface"],
): number {
  switch (surface) {
    case "Firm Soil": return 0.62;
    case "Loose Soil": return 0.42;
    case "Grass": return 0.45;
    case "Gravel": return 0.5;
    case "Sand": return 0.35;
    case "Mud": return 0.28;
    case "Concrete": return 0.82;
    case "Paved Yard": return 0.75;
    case "Mixed Surface": return 0.5;
    case "Unclassified Ground":
    default:
      return 0.5;
  }
}

function surfaceFriction(reconstruction: AccidentReconstruction): number {
  const scene = reconstruction.scene;
  const weather = scene.weather;
  const roadCoefficient =
    scene.roadSurface === "Wet" ? 0.52 : scene.roadSurface === "Damaged" ? 0.62 : 0.78;
  const groundCoefficient = groundSurfaceFriction(scene.groundSurface);

  let coefficient = usesGeneratedRoad(scene)
    ? scene.sceneEnvironment === "Mixed Site"
      ? (roadCoefficient + groundCoefficient) / 2
      : roadCoefficient
    : groundCoefficient;

  if (weather === "Rain") coefficient *= 0.82;
  if (weather === "Dust") coefficient *= 0.9;
  return coefficient;
}

export function getDefaultParticipantPhysics(
  participant: Pick<ReconstructionVehicle, "type">,
): ParticipantPhysicsProfile {
  switch (participant.type) {
    case "Bus":
      return {
        enabled: true,
        massKg: 12000,
        collisionRadiusMetres: 1.25,
        restitution: 0.1,
        rollingFriction: 1,
        lateralGrip: 0.72,
        brakingDecelerationMps2: 5.2,
        collisionShape: "Oriented Box",
        lengthMetres: 11.8,
        widthMetres: 2.55,
        collisionFriction: 0.72,
        momentOfInertiaScale: 1,
      };
    case "Truck":
      return {
        enabled: true,
        massKg: 9000,
        collisionRadiusMetres: 1.25,
        restitution: 0.08,
        rollingFriction: 1.05,
        lateralGrip: 0.68,
        brakingDecelerationMps2: 5,
        collisionShape: "Oriented Box",
        lengthMetres: 8.4,
        widthMetres: 2.5,
        collisionFriction: 0.76,
        momentOfInertiaScale: 1.05,
      };
    case "Motorcycle":
      return {
        enabled: true,
        massKg: 240,
        collisionRadiusMetres: 0.42,
        restitution: 0.22,
        rollingFriction: 0.75,
        lateralGrip: 0.9,
        brakingDecelerationMps2: 7,
        collisionShape: "Oriented Box",
        lengthMetres: 2.2,
        widthMetres: 0.82,
        collisionFriction: 0.52,
        momentOfInertiaScale: 0.72,
      };
    case "Bicycle":
      return {
        enabled: true,
        massKg: 95,
        collisionRadiusMetres: 0.34,
        restitution: 0.18,
        rollingFriction: 0.6,
        lateralGrip: 0.82,
        brakingDecelerationMps2: 4.5,
        collisionShape: "Oriented Box",
        lengthMetres: 1.85,
        widthMetres: 0.64,
        collisionFriction: 0.46,
        momentOfInertiaScale: 0.62,
      };
    case "Pedestrian":
    case "Officer":
    case "Witness":
      return {
        enabled: true,
        massKg: 75,
        collisionRadiusMetres: 0.38,
        restitution: 0.06,
        rollingFriction: 1.45,
        lateralGrip: 0.45,
        brakingDecelerationMps2: 3.8,
        collisionShape: "Circle",
        lengthMetres: 0.76,
        widthMetres: 0.76,
        collisionFriction: 0.5,
        momentOfInertiaScale: 0.65,
      };
    case "Car":
    default:
      return {
        enabled: true,
        massKg: 1450,
        collisionRadiusMetres: 0.92,
        restitution: 0.14,
        rollingFriction: 0.92,
        lateralGrip: 0.82,
        brakingDecelerationMps2: 7.2,
        collisionShape: "Oriented Box",
        lengthMetres: 4.5,
        widthMetres: 1.82,
        collisionFriction: 0.66,
        momentOfInertiaScale: 1,
      };
  }
}

export function getDefaultSceneObjectPhysics(
  object: Pick<
    ReconstructionSceneObject,
    "type" | "severity" | "scale" | "lengthMetres" | "widthMetres"
  >,
): SceneObjectPhysicsProfile {
  if (object.type === "Pothole") {
    const severityFactor =
      object.severity === "Critical" ? 0.82 :
      object.severity === "High" ? 0.88 :
      object.severity === "Medium" ? 0.93 : 0.97;
    const diameter = Math.max(
      0.25,
      Number(object.widthMetres ?? object.scale * 1.8),
    );
    return {
      enabled: true,
      collidable: false,
      collisionRadiusMetres: diameter / 2,
      restitution: 0,
      surfaceFrictionMultiplier: 1,
      speedLossFactor: severityFactor,
      deflectionDegrees:
        object.severity === "Critical" ? 5 :
        object.severity === "High" ? 3 :
        object.severity === "Medium" ? 1.5 : 0.6,
      collisionShape: "Circle",
      lengthMetres: diameter,
      widthMetres: diameter,
      collisionFriction: 0.9,
    };
  }

  if (LOW_GRIP_OBJECT_TYPES.has(object.type)) {
    const diameter = Math.max(
      0.4,
      Number(object.widthMetres ?? object.scale * 2.6),
    );
    return {
      enabled: true,
      collidable: false,
      collisionRadiusMetres: diameter / 2,
      restitution: 0,
      surfaceFrictionMultiplier: object.type === "Oil Spill" ? 0.28 : 0.58,
      speedLossFactor: 0.96,
      deflectionDegrees: object.type === "Loose Gravel" ? 5 : 2,
      collisionShape: "Circle",
      lengthMetres: diameter,
      widthMetres: diameter,
      collisionFriction: 0.2,
    };
  }

  if (SOFT_OBJECT_TYPES.has(object.type)) {
    const length = Math.max(
      0.45,
      Number(object.lengthMetres ?? object.scale * 1.3),
    );
    const width = Math.max(
      0.35,
      Number(object.widthMetres ?? object.scale * 0.9),
    );
    const speedLossFactor =
      object.type === "Fallen Branch" ? 0.82 :
      object.type === "Debris" || object.type === "Vehicle Part" ? 0.88 :
      object.type === "Bush" ? 0.91 : 0.96;
    return {
      enabled: true,
      collidable: false,
      collisionRadiusMetres: Math.max(0.2, Math.min(length, width) / 2),
      restitution: 0.03,
      surfaceFrictionMultiplier: 1,
      speedLossFactor,
      deflectionDegrees: object.type === "Fallen Branch" ? 4 : 1.5,
      collisionShape: "Oriented Box",
      lengthMetres: length,
      widthMetres: width,
      collisionFriction: 0.28,
    };
  }

  const solid = SOLID_OBJECT_TYPES.has(object.type);
  const longBarrier =
    object.type === "Wall" ||
    object.type === "Guardrail" ||
    object.type === "Road Barrier" ||
    object.type === "Fence";
  const parkedVehicle = object.type === "Parked Vehicle";
  const busStop = object.type === "Bus Stop";
  const circular =
    object.type === "Tree" ||
    object.type === "Street Light" ||
    object.type === "Traffic Light" ||
    object.type === "Stop Sign" ||
    object.type === "Give Way Sign" ||
    object.type === "Speed Limit Sign";
  const length = longBarrier
    ? Math.max(1, Number(object.lengthMetres ?? 4))
    : parkedVehicle
      ? Math.max(3.8, Number(object.lengthMetres ?? 4.5))
      : busStop
        ? Math.max(2.5, Number(object.lengthMetres ?? 4))
        : Math.max(0.5, object.scale * 1.2);
  const width = longBarrier
    ? Math.max(0.18, Number(object.widthMetres ?? 0.32))
    : parkedVehicle
      ? Math.max(1.6, Number(object.widthMetres ?? 1.9))
      : busStop
        ? Math.max(1, Number(object.widthMetres ?? 1.4))
        : Math.max(0.3, object.scale * 0.7);
  const radius = circular
    ? Math.max(0.18, object.scale * (object.type === "Tree" ? 0.55 : 0.22))
    : Math.max(0.25, Math.min(length, width) / 2);

  return {
    enabled: solid,
    collidable: solid,
    collisionRadiusMetres: radius,
    restitution:
      object.type === "Road Barrier" || object.type === "Guardrail"
        ? 0.2
        : object.type === "Traffic Cone" || object.type === "Bush"
          ? 0.02
          : 0.08,
    surfaceFrictionMultiplier: 1,
    speedLossFactor:
      object.type === "Tree" || object.type === "Street Light"
        ? 0.28
        : object.type === "Traffic Cone" || object.type === "Bush"
          ? 0.82
          : object.type === "Fallen Branch" || object.type === "Debris"
            ? 0.62
            : 0.55,
    deflectionDegrees: 0,
    collisionShape: circular ? "Circle" : "Oriented Box",
    lengthMetres: circular ? radius * 2 : length,
    widthMetres: circular ? radius * 2 : width,
    collisionFriction: longBarrier ? 0.82 : parkedVehicle ? 0.68 : 0.72,
  };
}

export function derivePrimaryCollisionPoint(
  reconstruction: AccidentReconstruction,
): ReconstructionPosition | null {
  const impactPoints = reconstruction.vehicles
    .flatMap((participant) => participant.pathPoints)
    .filter((point) => point.action === "Impact")
    .map((point) => point.position);

  if (impactPoints.length === 0) return null;

  return {
    x: impactPoints.reduce((sum, point) => sum + point.x, 0) / impactPoints.length,
    y: impactPoints.reduce((sum, point) => sum + point.y, 0) / impactPoints.length,
  };
}

function bodyMomentOfInertia(body: SimulationBody): number {
  return calculatePlanarMomentOfInertia(
    body.profile.massKg,
    participantDimensions(body.profile),
    body.profile.momentOfInertiaScale,
  );
}

function applyImpulseToBody(
  body: SimulationBody,
  impulse: Vector2,
  contactPoint: Vector2,
): void {
  body.velocity = {
    x: body.velocity.x + impulse.x / body.profile.massKg,
    y: body.velocity.y + impulse.y / body.profile.massKg,
  };
  const offset = {
    x: contactPoint.x - body.position.x,
    y: contactPoint.y - body.position.y,
  };
  const angularDeltaRadiansPerSecond =
    cross(offset, impulse) / Math.max(0.001, bodyMomentOfInertia(body));
  body.angularVelocityDegreesPerSecond +=
    (angularDeltaRadiansPerSecond * 180) / Math.PI;

  stabiliseBodyAngularVelocity(body);
}

function contactVelocity(body: SimulationBody, contactPoint: Vector2): Vector2 {
  return velocityAtContactPoint(
    body.velocity,
    (body.angularVelocityDegreesPerSecond * Math.PI) / 180,
    {
      x: contactPoint.x - body.position.x,
      y: contactPoint.y - body.position.y,
    },
  );
}

function resolveParticipantCollision(
  left: SimulationBody,
  right: SimulationBody,
  manifold: PhysicsCollisionManifold,
): CollisionImpulseResult {
  const normal = normalise(manifold.normal);
  const contactPoint = manifold.contactPoint;
  const leftBeforeVelocity = { ...left.velocity };
  const rightBeforeVelocity = { ...right.velocity };
  const leftBeforeAngular = left.angularVelocityDegreesPerSecond;
  const rightBeforeAngular = right.angularVelocityDegreesPerSecond;
  const leftContactVelocity = contactVelocity(left, contactPoint);
  const rightContactVelocity = contactVelocity(right, contactPoint);
  const relativeVelocity = {
    x: rightContactVelocity.x - leftContactVelocity.x,
    y: rightContactVelocity.y - leftContactVelocity.y,
  };
  const velocityAlongNormal = dot(relativeVelocity, normal);
  const impactAngleDegrees = angleBetweenDegrees(
    leftBeforeVelocity,
    rightBeforeVelocity,
  );

  if (velocityAlongNormal >= -0.03) {
    return {
      collided: false,
      impactEnergyKj: 0,
      relativeSpeedKmh: mpsToKmh(magnitude(relativeVelocity)),
      impactAngleDegrees,
      normalImpulseNs: 0,
      frictionImpulseNs: 0,
      totalImpulseNs: 0,
      outcome: "Deflect",
      participantChanges: [],
      angularVelocityChangesDegPerSecond: {},
    };
  }

  const leftOffset = {
    x: contactPoint.x - left.position.x,
    y: contactPoint.y - left.position.y,
  };
  const rightOffset = {
    x: contactPoint.x - right.position.x,
    y: contactPoint.y - right.position.y,
  };
  const inverseLeftMass = 1 / left.profile.massKg;
  const inverseRightMass = 1 / right.profile.massKg;
  const inverseLeftInertia = 1 / Math.max(0.001, bodyMomentOfInertia(left));
  const inverseRightInertia = 1 / Math.max(0.001, bodyMomentOfInertia(right));
  const leftNormalLever = cross(leftOffset, normal);
  const rightNormalLever = cross(rightOffset, normal);
  const normalDenominator =
    inverseLeftMass +
    inverseRightMass +
    leftNormalLever * leftNormalLever * inverseLeftInertia +
    rightNormalLever * rightNormalLever * inverseRightInertia;
  const restitution = Math.min(left.profile.restitution, right.profile.restitution);
  const normalImpulseMagnitude =
    (-(1 + restitution) * velocityAlongNormal) /
    Math.max(0.000001, normalDenominator);
  const normalImpulse = {
    x: normal.x * normalImpulseMagnitude,
    y: normal.y * normalImpulseMagnitude,
  };

  applyImpulseToBody(left, { x: -normalImpulse.x, y: -normalImpulse.y }, contactPoint);
  applyImpulseToBody(right, normalImpulse, contactPoint);

  const relativeAfterNormal = {
    x: contactVelocity(right, contactPoint).x - contactVelocity(left, contactPoint).x,
    y: contactVelocity(right, contactPoint).y - contactVelocity(left, contactPoint).y,
  };
  const tangentRaw = {
    x: relativeAfterNormal.x - normal.x * dot(relativeAfterNormal, normal),
    y: relativeAfterNormal.y - normal.y * dot(relativeAfterNormal, normal),
  };
  let frictionImpulseMagnitude = 0;
  if (magnitude(tangentRaw) > 0.0001) {
    const tangent = normalise(tangentRaw);
    const leftTangentLever = cross(leftOffset, tangent);
    const rightTangentLever = cross(rightOffset, tangent);
    const tangentDenominator =
      inverseLeftMass +
      inverseRightMass +
      leftTangentLever * leftTangentLever * inverseLeftInertia +
      rightTangentLever * rightTangentLever * inverseRightInertia;
    const unconstrainedFrictionImpulse =
      -dot(relativeAfterNormal, tangent) /
      Math.max(0.000001, tangentDenominator);
    const frictionCoefficient = Math.sqrt(
      left.profile.collisionFriction * right.profile.collisionFriction,
    );
    const maximumFrictionImpulse = frictionCoefficient * normalImpulseMagnitude;
    frictionImpulseMagnitude = clamp(
      unconstrainedFrictionImpulse,
      -maximumFrictionImpulse,
      maximumFrictionImpulse,
    );
    const frictionImpulse = {
      x: tangent.x * frictionImpulseMagnitude,
      y: tangent.y * frictionImpulseMagnitude,
    };
    applyImpulseToBody(left, { x: -frictionImpulse.x, y: -frictionImpulse.y }, contactPoint);
    applyImpulseToBody(right, frictionImpulse, contactPoint);
  }

  const effectiveMass = 1 / Math.max(0.000001, normalDenominator);
  const impactEnergyKj =
    (0.5 * effectiveMass * velocityAlongNormal * velocityAlongNormal *
      (1 - restitution * restitution)) /
    1000;
  const leftDeflection = Math.abs(
    angleDifferenceDegrees(leftBeforeVelocity, left.velocity),
  );
  const rightDeflection = Math.abs(
    angleDifferenceDegrees(rightBeforeVelocity, right.velocity),
  );
  const leftSpinChange =
    left.angularVelocityDegreesPerSecond - leftBeforeAngular;
  const rightSpinChange =
    right.angularVelocityDegreesPerSecond - rightBeforeAngular;

  const outgoingRelativeVelocity = {
    x: right.velocity.x - left.velocity.x,
    y: right.velocity.y - left.velocity.y,
  };
  const sharesMotion =
    restitution <= 0.18 && magnitude(outgoingRelativeVelocity) <= 0.75;
  const sharedMotionStops =
    sharesMotion &&
    (magnitude(left.velocity) + magnitude(right.velocity)) / 2 <= 0.5;
  const outcome: CollisionKinematicOutcome = sharesMotion
    ? sharedMotionStops
      ? "Stick"
      : "SlideTogether"
    : leftDeflection >= 35 ||
        rightDeflection >= 35 ||
        Math.abs(leftSpinChange) >= 35 ||
        Math.abs(rightSpinChange) >= 35
      ? "Ricochet"
      : "Deflect";

  const leftOutcome = classifyParticipantOutcome({
    incomingVelocityMps: leftBeforeVelocity,
    outgoingVelocityMps: left.velocity,
    sharesMotionWithOtherBody: sharesMotion,
    sharedMotionStops,
  });
  const rightOutcome = classifyParticipantOutcome({
    incomingVelocityMps: rightBeforeVelocity,
    outgoingVelocityMps: right.velocity,
    sharesMotionWithOtherBody: sharesMotion,
    sharedMotionStops,
  });

  left.primaryResponseAction =
    leftOutcome === "Ricochet" ? "Ricochet" : "Deflect";
  right.primaryResponseAction =
    rightOutcome === "Ricochet" ? "Ricochet" : "Deflect";
  left.primaryResponseLabel =
    outcome === "Stick"
      ? `Stopped together after impact with ${right.participant.name}`
      : outcome === "SlideTogether"
        ? `Sliding together after impact with ${right.participant.name}`
        : `${left.primaryResponseAction} after impact with ${right.participant.name}`;
  right.primaryResponseLabel =
    outcome === "Stick"
      ? `Stopped together after impact with ${left.participant.name}`
      : outcome === "SlideTogether"
        ? `Sliding together after impact with ${left.participant.name}`
        : `${right.primaryResponseAction} after impact with ${left.participant.name}`;

  const leftImpulse = {
    x: left.profile.massKg * (left.velocity.x - leftBeforeVelocity.x),
    y: left.profile.massKg * (left.velocity.y - leftBeforeVelocity.y),
  };
  const rightImpulse = {
    x: right.profile.massKg * (right.velocity.x - rightBeforeVelocity.x),
    y: right.profile.massKg * (right.velocity.y - rightBeforeVelocity.y),
  };
  const totalImpulseNs = Math.hypot(
    normalImpulseMagnitude,
    frictionImpulseMagnitude,
  );

  return {
    collided: true,
    impactEnergyKj,
    relativeSpeedKmh: mpsToKmh(magnitude(relativeVelocity)),
    impactAngleDegrees,
    normalImpulseNs: Math.abs(normalImpulseMagnitude),
    frictionImpulseNs: Math.abs(frictionImpulseMagnitude),
    totalImpulseNs,
    outcome,
    participantChanges: [
      {
        participantId: left.participant.id,
        participantType:
          left.participant.type,
        massKg: left.profile.massKg,
        momentOfInertiaKgM2: bodyMomentOfInertia(left),
        impactPosition: { ...left.position },
        incomingVelocity: leftBeforeVelocity,
        outgoingVelocity: { ...left.velocity },
        incomingAngularVelocityDegreesPerSecond: leftBeforeAngular,
        outgoingAngularVelocityDegreesPerSecond:
          left.angularVelocityDegreesPerSecond,
        impulseNs: leftImpulse,
        outcome: leftOutcome,
      },
      {
        participantId: right.participant.id,
        participantType:
          right.participant.type,
        massKg: right.profile.massKg,
        momentOfInertiaKgM2: bodyMomentOfInertia(right),
        impactPosition: { ...right.position },
        incomingVelocity: rightBeforeVelocity,
        outgoingVelocity: { ...right.velocity },
        incomingAngularVelocityDegreesPerSecond: rightBeforeAngular,
        outgoingAngularVelocityDegreesPerSecond:
          right.angularVelocityDegreesPerSecond,
        impulseNs: rightImpulse,
        outcome: rightOutcome,
      },
    ],
    angularVelocityChangesDegPerSecond: {
      [left.participant.id]: Number(leftSpinChange.toFixed(3)),
      [right.participant.id]: Number(rightSpinChange.toFixed(3)),
    },
  };
}

function resolveStaticObjectCollision(
  body: SimulationBody,
  objectProfile: ResolvedSceneObjectPhysicsProfile,
  manifold: PhysicsCollisionManifold,
): CollisionImpulseResult {
  const normal = normalise(manifold.normal);
  const contactPoint = manifold.contactPoint;
  const beforeVelocity = { ...body.velocity };
  const beforeAngular = body.angularVelocityDegreesPerSecond;
  const bodyContactVelocity = contactVelocity(body, contactPoint);
  const relativeVelocity = {
    x: -bodyContactVelocity.x,
    y: -bodyContactVelocity.y,
  };
  const velocityAlongNormal = dot(relativeVelocity, normal);
  const impactAngleDegrees = angleBetweenDegrees(beforeVelocity, {
    x: -normal.x,
    y: -normal.y,
  });

  if (velocityAlongNormal >= -0.03) {
    return {
      collided: false,
      impactEnergyKj: 0,
      relativeSpeedKmh: mpsToKmh(magnitude(relativeVelocity)),
      impactAngleDegrees,
      normalImpulseNs: 0,
      frictionImpulseNs: 0,
      totalImpulseNs: 0,
      outcome: "Deflect",
      participantChanges: [],
      angularVelocityChangesDegPerSecond: {},
    };
  }

  const offset = {
    x: contactPoint.x - body.position.x,
    y: contactPoint.y - body.position.y,
  };
  const inverseMass = 1 / body.profile.massKg;

  /*
   * [RoadSafe:FiniteSceneObjectMassV1]
   * Very heavy objects converge toward the former static-world response.
   * Lighter collidable objects absorb more of the contact impulse.
   */
  const inverseObjectMass =
    1 /
    Math.max(
      0.1,
      objectProfile.massKg,
    );

  const inverseInertia = 1 / Math.max(0.001, bodyMomentOfInertia(body));
  const normalLever = cross(offset, normal);
  const normalDenominator =
    inverseMass +
    inverseObjectMass +
    normalLever * normalLever * inverseInertia;
  const restitution = Math.min(body.profile.restitution, objectProfile.restitution);
  const normalImpulseMagnitude =
    (-(1 + restitution) * velocityAlongNormal) /
    Math.max(0.000001, normalDenominator);
  const normalImpulse = {
    x: normal.x * normalImpulseMagnitude,
    y: normal.y * normalImpulseMagnitude,
  };
  applyImpulseToBody(body, { x: -normalImpulse.x, y: -normalImpulse.y }, contactPoint);

  const relativeAfterNormal = {
    x: -contactVelocity(body, contactPoint).x,
    y: -contactVelocity(body, contactPoint).y,
  };
  const tangentRaw = {
    x: relativeAfterNormal.x - normal.x * dot(relativeAfterNormal, normal),
    y: relativeAfterNormal.y - normal.y * dot(relativeAfterNormal, normal),
  };
  let frictionImpulseMagnitude = 0;
  if (magnitude(tangentRaw) > 0.0001) {
    const tangent = normalise(tangentRaw);
    const tangentLever = cross(offset, tangent);
    const tangentDenominator =
      inverseMass +
      inverseObjectMass +
      tangentLever * tangentLever * inverseInertia;
    const unconstrainedFrictionImpulse =
      -dot(relativeAfterNormal, tangent) /
      Math.max(0.000001, tangentDenominator);
    const frictionCoefficient = Math.sqrt(
      body.profile.collisionFriction * objectProfile.collisionFriction,
    );
    const maximumFrictionImpulse = frictionCoefficient * normalImpulseMagnitude;
    frictionImpulseMagnitude = clamp(
      unconstrainedFrictionImpulse,
      -maximumFrictionImpulse,
      maximumFrictionImpulse,
    );
    const frictionImpulse = {
      x: tangent.x * frictionImpulseMagnitude,
      y: tangent.y * frictionImpulseMagnitude,
    };
    applyImpulseToBody(body, { x: -frictionImpulse.x, y: -frictionImpulse.y }, contactPoint);
  }

  body.velocity = {
    x: body.velocity.x * objectProfile.speedLossFactor,
    y: body.velocity.y * objectProfile.speedLossFactor,
  };
  body.angularVelocityDegreesPerSecond *=
    0.65 + objectProfile.speedLossFactor * 0.35;
  const effectiveMass = 1 / Math.max(0.000001, normalDenominator);
  const impactEnergyKj =
    (0.5 * effectiveMass * velocityAlongNormal * velocityAlongNormal *
      (1 - restitution * restitution)) /
    1000;
  const angularChange = body.angularVelocityDegreesPerSecond - beforeAngular;
  const outcome = classifyParticipantOutcome({
    incomingVelocityMps: beforeVelocity,
    outgoingVelocityMps: body.velocity,
  });
  const impulseNs = {
    x: body.profile.massKg * (body.velocity.x - beforeVelocity.x),
    y: body.profile.massKg * (body.velocity.y - beforeVelocity.y),
  };
  const totalImpulseNs = Math.hypot(
    normalImpulseMagnitude,
    frictionImpulseMagnitude,
  );

  return {
    collided: true,
    impactEnergyKj,
    relativeSpeedKmh: mpsToKmh(magnitude(relativeVelocity)),
    impactAngleDegrees,
    normalImpulseNs: Math.abs(normalImpulseMagnitude),
    frictionImpulseNs: Math.abs(frictionImpulseMagnitude),
    totalImpulseNs,
    outcome,
    participantChanges: [
      {
        participantId: body.participant.id,
        participantType:
          body.participant.type,
        massKg: body.profile.massKg,
        momentOfInertiaKgM2: bodyMomentOfInertia(body),
        impactPosition: { ...body.position },
        incomingVelocity: beforeVelocity,
        outgoingVelocity: { ...body.velocity },
        incomingAngularVelocityDegreesPerSecond: beforeAngular,
        outgoingAngularVelocityDegreesPerSecond:
          body.angularVelocityDegreesPerSecond,
        impulseNs,
        outcome,
      },
    ],
    angularVelocityChangesDegPerSecond: {
      [body.participant.id]: Number(angularChange.toFixed(3)),
    },
  };
}

function createImmediateParticipantKinematics(
  change: CollisionParticipantChange,
  width: number,
  height: number,
): ParticipantCollisionKinematics {
  const incomingMomentum = momentumVectorNs(
    change.massKg,
    change.incomingVelocity,
  );
  const outgoingMomentum = momentumVectorNs(
    change.massKg,
    change.outgoingVelocity,
  );
  const deltaVelocity = subtractVector(
    change.outgoingVelocity,
    change.incomingVelocity,
  );
  const incomingTranslationalKineticEnergyKj =
    translationalKineticEnergyKj(
      change.massKg,
      change.incomingVelocity,
    );
  const outgoingTranslationalKineticEnergyKj =
    translationalKineticEnergyKj(
      change.massKg,
      change.outgoingVelocity,
    );
  const incomingRotationalKineticEnergyKj =
    rotationalKineticEnergyKj(
      change.momentOfInertiaKgM2,
      change.incomingAngularVelocityDegreesPerSecond,
    );
  const outgoingRotationalKineticEnergyKj =
    rotationalKineticEnergyKj(
      change.momentOfInertiaKgM2,
      change.outgoingAngularVelocityDegreesPerSecond,
    );
  const impactPosition = scenePosition(
    change.impactPosition,
    width,
    height,
  );

  return {
    participantId: change.participantId,
    massKg: roundPhysicsValue(change.massKg, 2),
    impactPosition,
    finalPosition: impactPosition,
    incomingVelocityMps: {
      x: roundPhysicsValue(change.incomingVelocity.x),
      y: roundPhysicsValue(change.incomingVelocity.y),
    },
    outgoingVelocityMps: {
      x: roundPhysicsValue(change.outgoingVelocity.x),
      y: roundPhysicsValue(change.outgoingVelocity.y),
    },
    incomingSpeedKmh: roundPhysicsValue(
      mpsToKmh(vectorMagnitude(change.incomingVelocity)),
      2,
    ),
    outgoingSpeedKmh: roundPhysicsValue(
      mpsToKmh(vectorMagnitude(change.outgoingVelocity)),
      2,
    ),
    deltaVelocityMps: {
      x: roundPhysicsValue(deltaVelocity.x),
      y: roundPhysicsValue(deltaVelocity.y),
    },
    deltaVMetresPerSecond: roundPhysicsValue(
      vectorMagnitude(deltaVelocity),
    ),
    momentumBeforeNs: {
      x: roundPhysicsValue(incomingMomentum.x, 2),
      y: roundPhysicsValue(incomingMomentum.y, 2),
    },
    momentumAfterNs: {
      x: roundPhysicsValue(outgoingMomentum.x, 2),
      y: roundPhysicsValue(outgoingMomentum.y, 2),
    },
    impulseNs: {
      x: roundPhysicsValue(change.impulseNs.x, 2),
      y: roundPhysicsValue(change.impulseNs.y, 2),
    },
    impulseMagnitudeNs: roundPhysicsValue(
      vectorMagnitude(change.impulseNs),
      2,
    ),
    incomingTranslationalKineticEnergyKj: roundPhysicsValue(
      incomingTranslationalKineticEnergyKj,
    ),
    outgoingTranslationalKineticEnergyKj: roundPhysicsValue(
      outgoingTranslationalKineticEnergyKj,
    ),
    incomingRotationalKineticEnergyKj: roundPhysicsValue(
      incomingRotationalKineticEnergyKj,
    ),
    outgoingRotationalKineticEnergyKj: roundPhysicsValue(
      outgoingRotationalKineticEnergyKj,
    ),
    totalIncomingKineticEnergyKj: roundPhysicsValue(
      incomingTranslationalKineticEnergyKj +
        incomingRotationalKineticEnergyKj,
    ),
    totalOutgoingKineticEnergyKj: roundPhysicsValue(
      outgoingTranslationalKineticEnergyKj +
        outgoingRotationalKineticEnergyKj,
    ),
    postImpactTravelDistanceMetres: 0,
    postImpactDisplacementMetres: 0,
    outcome: change.outcome,
  };
}

function createCollisionKinematics(input: {
  collisionEventId: string;
  timeSeconds: number;
  contactPoint: ReconstructionPosition;
  participantIds: string[];
  result: CollisionImpulseResult;
  settings: ReconstructionPhysicsSettings;
  width: number;
  height: number;
}): CollisionKinematicsSummary {
  const participants = input.result.participantChanges.map((change) =>
    createImmediateParticipantKinematics(
      change,
      input.width,
      input.height,
    ),
  );
  const durationRange = normaliseContactDurationRangeMs(
    input.settings.contactDurationMinimumMs,
    input.settings.contactDurationMaximumMs,
  );
  const estimatedAverageForceRangeKn =
    estimateAverageForceRangeKn(
      input.result.totalImpulseNs,
      durationRange,
    );
  const totalIncomingTranslationalKineticEnergyKj =
    participants.reduce(
      (sum, participant) =>
        sum + participant.incomingTranslationalKineticEnergyKj,
      0,
    );
  const totalOutgoingTranslationalKineticEnergyKj =
    participants.reduce(
      (sum, participant) =>
        sum + participant.outgoingTranslationalKineticEnergyKj,
      0,
    );
  const totalIncomingRotationalKineticEnergyKj =
    participants.reduce(
      (sum, participant) =>
        sum + participant.incomingRotationalKineticEnergyKj,
      0,
    );
  const totalOutgoingRotationalKineticEnergyKj =
    participants.reduce(
      (sum, participant) =>
        sum + participant.outgoingRotationalKineticEnergyKj,
      0,
    );
  const totalIncomingKineticEnergyKj =
    totalIncomingTranslationalKineticEnergyKj +
    totalIncomingRotationalKineticEnergyKj;
  const totalOutgoingKineticEnergyKj =
    totalOutgoingTranslationalKineticEnergyKj +
    totalOutgoingRotationalKineticEnergyKj;

  return {
    collisionEventId: input.collisionEventId,
    timeSeconds: roundPhysicsValue(input.timeSeconds),
    contactPoint: input.contactPoint,
    participantIds: input.participantIds,
    relativeImpactSpeedKmh: roundPhysicsValue(
      input.result.relativeSpeedKmh,
      2,
    ),
    impactAngleDegrees: roundPhysicsValue(
      input.result.impactAngleDegrees,
      2,
    ),
    normalImpulseNs: roundPhysicsValue(
      input.result.normalImpulseNs,
      2,
    ),
    frictionImpulseNs: roundPhysicsValue(
      input.result.frictionImpulseNs,
      2,
    ),
    totalImpulseNs: roundPhysicsValue(
      input.result.totalImpulseNs,
      2,
    ),
    assumedContactDurationRangeMs: durationRange,
    estimatedAverageForceRangeKn: {
      minimum: roundPhysicsValue(
        estimatedAverageForceRangeKn.minimum,
        2,
      ),
      maximum: roundPhysicsValue(
        estimatedAverageForceRangeKn.maximum,
        2,
      ),
    },
    totalIncomingTranslationalKineticEnergyKj:
      roundPhysicsValue(
        totalIncomingTranslationalKineticEnergyKj,
      ),
    totalOutgoingTranslationalKineticEnergyKj:
      roundPhysicsValue(
        totalOutgoingTranslationalKineticEnergyKj,
      ),
    totalIncomingRotationalKineticEnergyKj:
      roundPhysicsValue(
        totalIncomingRotationalKineticEnergyKj,
      ),
    totalOutgoingRotationalKineticEnergyKj:
      roundPhysicsValue(
        totalOutgoingRotationalKineticEnergyKj,
      ),
    totalIncomingKineticEnergyKj: roundPhysicsValue(
      totalIncomingKineticEnergyKj,
    ),
    totalOutgoingKineticEnergyKj: roundPhysicsValue(
      totalOutgoingKineticEnergyKj,
    ),
    dissipatedKineticEnergyKj: roundPhysicsValue(
      Math.max(
        0,
        totalIncomingKineticEnergyKj -
          totalOutgoingKineticEnergyKj,
      ),
    ),
    solverEstimatedDissipatedEnergyKj:
      roundPhysicsValue(input.result.impactEnergyKj),
    outcome: input.result.outcome,
    participants,
  };
}

function enrichCollisionKinematicsWithTravel(input: {
  kinematics: CollisionKinematicsSummary;
  bodies: SimulationBody[];
  width: number;
  height: number;
}): CollisionKinematicsSummary {
  const participants = input.kinematics.participants.map(
    (participant) => {
      const body = input.bodies.find(
        (candidate) =>
          candidate.participant.id === participant.participantId,
      );

      if (!body) return participant;

      const impactWorldPosition = worldPosition(
        participant.impactPosition,
        input.width,
        input.height,
      );
      const travelPoints: PhysicsVector2D[] = [
        impactWorldPosition,
        ...body.trajectorySamples
          .filter(
            (sample) =>
              sample.timeSeconds >
              input.kinematics.timeSeconds + 0.0001,
          )
          .map((sample) => sample.position),
      ];
      const finalWorldPosition = { ...body.position };
      const lastTravelPoint = travelPoints.at(-1);

      if (
        !lastTravelPoint ||
        vectorMagnitude(
          subtractVector(finalWorldPosition, lastTravelPoint),
        ) > 0.0001
      ) {
        travelPoints.push(finalWorldPosition);
      }

      return {
        ...participant,
        finalPosition: scenePosition(
          finalWorldPosition,
          input.width,
          input.height,
        ),
        postImpactTravelDistanceMetres: roundPhysicsValue(
          distanceAlongPoints(travelPoints),
          2,
        ),
        postImpactDisplacementMetres: roundPhysicsValue(
          vectorMagnitude(
            subtractVector(
              finalWorldPosition,
              impactWorldPosition,
            ),
          ),
          2,
        ),
        timeToRestSeconds:
          body.restTimeSeconds === undefined
            ? undefined
            : roundPhysicsValue(
                Math.max(
                  0,
                  body.restTimeSeconds -
                    input.kinematics.timeSeconds,
                ),
                2,
              ),
      };
    },
  );

  return {
    ...input.kinematics,
    participants,
  };
}

function createPhysicsCollisionEvent(input: {
  id: string;
  timeSeconds: number;
  type: PhysicsCollisionEvent["type"];
  participantIds: string[];
  sceneObjectId?: string;
  contactPoint: ReconstructionPosition;
  normal: ReconstructionPosition;
  result: CollisionImpulseResult;
  settings: ReconstructionPhysicsSettings;
  width: number;
  height: number;
}): PhysicsCollisionEvent {
  const kinematics = createCollisionKinematics({
    collisionEventId: input.id,
    timeSeconds: quantiseSimulationTime(input.timeSeconds),
    contactPoint: input.contactPoint,
    participantIds: input.participantIds,
    result: input.result,
    settings: input.settings,
    width: input.width,
    height: input.height,
  });

  /*
   * [RoadSafe:CanonicalImpactResponseEventV1]
   *
   * Preserve the exact solver result before any viewer-specific animation is
   * applied. Old saved events remain valid because impactResponses is optional.
   */
  const impactResponses =
    createParticipantImpactResponses({
      collisionEventId:
        input.id,

      timeSeconds:
        quantiseSimulationTime(
          input.timeSeconds,
        ),

      participantIds:
        input.participantIds,

      contactPoint:
        input.contactPoint,

      collisionNormal:
        input.normal,

      relativeImpactSpeedKmh:
        input.result
          .relativeSpeedKmh,

      estimatedEnergyKj:
        input.result
          .impactEnergyKj,

      widthMetres:
        input.width,

      heightMetres:
        input.height,

      changes:
        input.result
          .participantChanges
          .map(
            (change) => ({
              participantId:
                change.participantId,

              participantType:
                change.participantType,

              impactPositionMetres:
                change.impactPosition,

              incomingVelocityMps:
                change.incomingVelocity,

              outgoingVelocityMps:
                change.outgoingVelocity,

              impulseNs:
                change.impulseNs,

              angularVelocityChangeDegreesPerSecond:
                change
                  .outgoingAngularVelocityDegreesPerSecond -
                change
                  .incomingAngularVelocityDegreesPerSecond,

              outcome:
                change.outcome,
            }),
          ),
    });

  return {
    id: input.id,
    timeSeconds: input.timeSeconds,
    type: input.type,
    participantIds: input.participantIds,
    sceneObjectId: input.sceneObjectId,
    contactPoint: input.contactPoint,
    normal: input.normal,
    relativeSpeedKmh: roundPhysicsValue(
      input.result.relativeSpeedKmh,
      2,
    ),
    impactAngleDegrees: roundPhysicsValue(
      input.result.impactAngleDegrees,
      2,
    ),
    normalImpulseNs: roundPhysicsValue(
      input.result.normalImpulseNs,
      2,
    ),
    frictionImpulseNs: roundPhysicsValue(
      input.result.frictionImpulseNs,
      2,
    ),
    totalImpulseNs: roundPhysicsValue(
      input.result.totalImpulseNs,
      2,
    ),
    estimatedEnergyKj: roundPhysicsValue(
      input.result.impactEnergyKj,
      2,
    ),
    estimatedAverageForceRangeKn:
      kinematics.estimatedAverageForceRangeKn,
    angularVelocityChangesDegPerSecond:
      input.result.angularVelocityChangesDegPerSecond,
    impactResponses,
    kinematics,
  };
}

function makePhysicsPoint(
  body: SimulationBody,
  timeSeconds: number,
  position: ReconstructionPosition,
  action: MovementPathPoint["action"],
  label: string,
  linkedSceneObjectId?: string,
): MovementPathPoint {
  return {
    id: createId("physics-point"),
    label,
    position,
    timeSeconds: quantiseSimulationTime(timeSeconds),
    speedKmh: Number(mpsToKmh(magnitude(body.velocity)).toFixed(1)),
    rotation: Number(normaliseDegrees(body.rotation).toFixed(1)),
    action,
    linkedSceneObjectId,
    notes: "Generated by the RoadSafe deterministic 2D physics preview.",
  };
}


/*
 * RoadSafe post-collision stability invariant:
 * every physics takeover or secondary contact gets one authoritative sample at
 * the exact contact time. Any already-recorded pre-contact sample from the same
 * simulation step is removed before that transition is stored.
 */
function maximumAngularVelocityDegreesPerSecond(
  body: SimulationBody,
): number {
  switch (body.participant.type) {
    case "Bus":
      return 70;
    case "Truck":
      return 85;
    case "Car":
      return 180;
    case "Motorcycle":
    case "Bicycle":
      return 320;
    case "Pedestrian":
    case "Officer":
    case "Witness":
      return 540;
    default:
      return 180;
  }
}

function stabiliseBodyAngularVelocity(
  body: SimulationBody,
): void {
  if (
    !Number.isFinite(
      body.angularVelocityDegreesPerSecond,
    )
  ) {
    body.angularVelocityDegreesPerSecond = 0;
    return;
  }

  const maximum =
    maximumAngularVelocityDegreesPerSecond(body);

  body.angularVelocityDegreesPerSecond = clamp(
    body.angularVelocityDegreesPerSecond,
    -maximum,
    maximum,
  );
}

function normaliseDegrees(
  degrees: number,
): number {
  if (!Number.isFinite(degrees)) {
    return 0;
  }

  return ((degrees % 360) + 360) % 360;
}

function recordPhysicsTransition(
  body: SimulationBody,
  timeSeconds: number,
  width: number,
  height: number,
  action: MovementPathPoint["action"],
  label: string,
  linkedSceneObjectId?: string,
): number {
  const previousLength = body.points.length;

  /*
   * A point may already have been recorded at the end of this simulation step
   * before swept collision resolution moved the body back to its exact contact
   * pose. Delete that stale future sample before storing the corrected state.
   */
  body.points = body.points.filter(
    (point) =>
      point.timeSeconds <
      timeSeconds - 0.0001,
  );

  stabiliseBodyAngularVelocity(body);
  body.rotation = normaliseDegrees(body.rotation);

  body.points.push({
    id: createId("physics-transition"),
    label,
    position: scenePosition(
      body.position,
      width,
      height,
    ),
    timeSeconds: quantiseSimulationTime(timeSeconds),
    speedKmh: Number(
      mpsToKmh(
        magnitude(body.velocity),
      ).toFixed(1),
    ),
    rotation: Number(
      body.rotation.toFixed(1),
    ),
    action,
    linkedSceneObjectId,
    notes:
      "Physics takes over from the participant's guided route at the exact collision state. [RoadSafe:PostCollisionTransitionV1]",
  });

  return (
    body.points.length -
    previousLength
  );
}

const playbackPhysicsSignatureCache = new Map<string, string>();

function createPlaybackPhysicsSignature(
  source: AccidentReconstruction,
): string {
  const dimensions = getReconstructionWorldDimensions(source);
  return JSON.stringify({
    durationSeconds: source.durationSeconds,
    collisionPoint: source.collisionPoint,
    dimensions,
    scene: {
      environment: source.scene.sceneEnvironment,
      roadSurface: source.scene.roadSurface,
      groundSurface: source.scene.groundSurface,
      weather: source.scene.weather,
      roadLayout: source.scene.roadLayout,
      laneCount: source.scene.laneCount,
      extractedAt: source.scene.realSceneGeometry?.extractedAt,
    },
    physicsSettings: source.physicsSettings,
    vehicles: source.vehicles.map((participant) => ({
      id: participant.id,
      type: participant.type,
      estimatedSpeedKmh: participant.estimatedSpeedKmh,
      physics: participant.physics,
      pathPoints: participant.pathPoints
        .filter((point) => !isPhysicsGeneratedPathPoint(point))
        .map((point) => ({
          id: point.id,
          position: point.position,
          timeSeconds: point.timeSeconds,
          speedKmh: point.speedKmh,
          rotation: point.rotation,
          action: point.action,
          linkedSceneObjectId: point.linkedSceneObjectId,
        })),
    })),
    sceneObjects: source.sceneObjects.map((object) => ({
      id: object.id,
      type: object.type,
      position: object.position,
      rotation: object.rotation,
      scale: object.scale,
      severity: object.severity,
      visible: object.visible,
      widthMetres: object.widthMetres,
      lengthMetres: object.lengthMetres,
      depthCentimetres: object.depthCentimetres,
      physics: object.physics,
    })),
  });
}


/*
 * [RoadSafe:CleanPhysicsInputV1]
 *
 * Every new simulation starts from investigator-authored movement only.
 * Generated samples from a previous simulation may never become inputs to a
 * later simulation.
 */
function createCleanPhysicsInput(
  source: AccidentReconstruction,
): AccidentReconstruction {
  const vehicles =
    source.vehicles.map(
      (participant) => {
        const authoredPathPoints =
          sortMovementPathPoints(
            participant.pathPoints,
          ).filter(
            (point) =>
              !isPhysicsGeneratedPathPoint(
                point,
              ),
          );

        return syncLegacyParticipantFields({
          ...participant,
          pathPoints:
            authoredPathPoints,
        });
      },
    );

  return {
    ...source,
    vehicles,
    lastPhysicsSimulation:
      undefined,
    timelineEvents:
      source.timelineEvents.filter(
        (event) =>
          !event.id.startsWith(
            "physics-event",
          ),
      ),
  };
}

export function preparePhysicsForPlayback(
  source: AccidentReconstruction,
): AccidentReconstruction {
  /*
   * [RoadSafe:RapierDynamicsPreserveOnPlaybackV1]
   *
   * Physics-affecting edits already invalidate lastPhysicsSimulation throughout
   * the editor. Therefore a surviving Rapier result is still current and must
   * not be replaced by the legacy synchronous fallback when playback starts.
   */
  if (
    source.lastPhysicsSimulation?.dynamicsEngine ===
    "Rapier 3D Deterministic"
  ) {
    return source;
  }

  const settings =
    normaliseReconstructionPhysicsSettings({
      ...DEFAULT_PHYSICS_SETTINGS,
      ...(source.physicsSettings ?? {}),
    });
  const shouldRun =
    settings.enabled &&
    settings.mode === "Physics After Primary Impact" &&
    settings.autoRunOnPlay &&
    source.vehicles.length > 0;

  if (!shouldRun) {
    return source.physicsSettings ? source : { ...source, physicsSettings: settings };
  }

  const signature = createPlaybackPhysicsSignature(source);
  if (
    source.lastPhysicsSimulation &&
    playbackPhysicsSignatureCache.get(source.id) === signature
  ) {
    return source;
  }

  const simulated = applyPhysicsSimulation(source);
  playbackPhysicsSignatureCache.set(
    simulated.id,
    createPlaybackPhysicsSignature(simulated),
  );
  return simulated;
}

export function applyPhysicsSimulation(
  inputSource: AccidentReconstruction,
): AccidentReconstruction {
  const source =
    createCleanPhysicsInput(
      inputSource,
    );
  const settings =
    normaliseReconstructionPhysicsSettings({
      ...DEFAULT_PHYSICS_SETTINGS,
      ...(source.physicsSettings ?? {}),
    });
  if (!settings.enabled || settings.mode === "Guided Paths") {
    return {
      ...source,
      physicsSettings: settings,
      lastPhysicsSimulation: {
        solverVersion: "RoadSafe Physics V2",
        dynamicsEngine: "RoadSafe Legacy 2D",
        dynamicsEngineVersion: "RoadSafe Physics V2",
        ranAt: new Date().toISOString(),
        participantCollisions: 0,
        primaryImpactTimeSeconds: source.durationSeconds / 2,
        estimatedImpactEnergyKj: 0,
        solidObjectImpacts: 0,
        potholeInteractions: 0,
        surfaceInteractions: 0,
        generatedPathPoints: 0,
        simulatedDurationSeconds: source.durationSeconds,
        collisionEvents: [],
        participantKinematics: [],
        totalIncomingKineticEnergyKj: 0,
        totalOutgoingKineticEnergyKj: 0,
        totalDissipatedKineticEnergyKj: 0,
        totalPostImpactTravelDistanceMetres: 0,
        warnings: ["Physics was not applied because Guided Paths mode is selected."],
      },
    };
  }

  const {
    widthMetres: width,
    heightMetres: height,
  } = getReconstructionWorldDimensions(source);
  const participants = source.vehicles.filter((participant) => participant.physics?.enabled ?? true);
  const warnings: string[] = [];
  const collisionEvents: PhysicsCollisionEvent[] = [];

  if (!usesGeneratedRoad(source.scene) && source.scene.groundSurface === "Unclassified Ground") {
    warnings.push(
      "Ground surface is unclassified. Physics uses a generic 0.50 friction estimate until the officer classifies the site.",
    );
  }
  if (source.scene.sceneEnvironment === "Mixed Site") {
    warnings.push(
      "Mixed Site currently uses a blended road/ground friction estimate. Surface-region physics is not yet enabled.",
    );
  }

  if (settings.collisionToleranceMetres > 0.35) {
    warnings.push(
      `Collision tolerance was limited to 0.35 m for physical contact; the stored value is ${settings.collisionToleranceMetres.toFixed(2)} m.`,
    );
  }

  if (participants.length === 0) {
    warnings.push("No physics-enabled participants were available.");
  }

  const step = clamp(settings.timeStepSeconds, 0.04, 0.5);
  const detectedParticipantContact = detectEarliestParticipantContact(
    participants,
    settings,
    width,
    height,
    source.durationSeconds,
  );
  const detectedObjectContact = detectEarliestSceneObjectContact(
    participants,
    source.sceneObjects,
    settings,
    width,
    height,
    source.durationSeconds,
  );
  const authoredImpactTimes = participants
    .map((participant) => getImpactPoint(participant).timeSeconds)
    .sort((left, right) => left - right);
  const authoredImpactTime = authoredImpactTimes.length
    ? authoredImpactTimes[Math.floor(authoredImpactTimes.length / 2)]
    : source.durationSeconds / 2;
  const primaryEvent = [
    { kind: "authored" as const, timeSeconds: authoredImpactTime },
    ...(detectedParticipantContact
      ? [{
          kind: "participant" as const,
          timeSeconds: detectedParticipantContact.timeSeconds,
        }]
      : []),
    ...(detectedObjectContact
      ? [{
          kind: "object" as const,
          timeSeconds: detectedObjectContact.timeSeconds,
        }]
      : []),
  ].reduce((earliest, candidate) =>
    candidate.timeSeconds < earliest.timeSeconds ? candidate : earliest,
  );
  const primaryImpactTime = primaryEvent.timeSeconds;
  const impactTime = primaryEvent.kind === "object"
    ? Math.max(0, primaryImpactTime - step)
    : primaryImpactTime;
  const activeParticipantContact =
    primaryEvent.kind === "participant" ? detectedParticipantContact : null;
  const activeObjectContact =
    primaryEvent.kind === "object" ? detectedObjectContact : null;
  const bodies: SimulationBody[] = participants.map((participant) => {
    const profile = resolveParticipantPhysicsProfile(participant);
    const authoredImpact = getImpactPoint(participant);
    const state =
      getParticipantStateAtTime(
        participant,
        impactTime,
        {
          widthMetres: width,
          heightMetres: height,
        },
      );
    const position = participantWorldPositionAtTime(
      participant,
      impactTime,
      width,
      height,
    );
    const incomingVelocity = participantVelocityAtTime(
      participant,
      impactTime,
      width,
      height,
      Math.max(0.03, Math.min(0.12, settings.timeStepSeconds)),
    );
    return {
      participant,
      profile,
      impactPoint: {
        ...authoredImpact,
        position: scenePosition(position, width, height),
        timeSeconds: impactTime,
        speedKmh: state.speedKmh,
        rotation: state.rotation,
      },
      position,
      previousPosition: { ...position },
      velocity: { ...incomingVelocity },
      incomingVelocity: { ...incomingVelocity },
      rotation: rotationFromVelocity(incomingVelocity, state.rotation),
      previousRotation: rotationFromVelocity(incomingVelocity, state.rotation),
      angularVelocityDegreesPerSecond: 0,
      timeSeconds: impactTime,
      points: [],
      trajectorySamples: [
        {
          timeSeconds: impactTime,
          position: { ...position },
          velocity: { ...incomingVelocity },
          angularVelocityDegreesPerSecond: 0,
        },
      ],
      stopped: false,
      collidedWithParticipants: new Set<string>(),
      collidedWithObjects: new Set<string>(),
    };
  });

  let participantCollisions = 0;
  let estimatedImpactEnergyKj = 0;
  const collisionTolerance = physicalCollisionTolerance(settings);
  for (let leftIndex = 0; leftIndex < bodies.length; leftIndex += 1) {
    for (let rightIndex = leftIndex + 1; rightIndex < bodies.length; rightIndex += 1) {
      const left = bodies[leftIndex];
      const right = bodies[rightIndex];
      const isDetectedPair = activeParticipantContact &&
        ((left.participant.id === activeParticipantContact.leftId &&
          right.participant.id === activeParticipantContact.rightId) ||
          (left.participant.id === activeParticipantContact.rightId &&
            right.participant.id === activeParticipantContact.leftId));
      const manifold: PhysicsCollisionManifold | null =
        isDetectedPair && activeParticipantContact
          ? (() => {
              const sameOrder = left.participant.id === activeParticipantContact.leftId;
              return {
                normal: sameOrder
                  ? activeParticipantContact.normal
                  : {
                      x: -activeParticipantContact.normal.x,
                      y: -activeParticipantContact.normal.y,
                    },
                penetrationMetres: 0,
                contactPoint: activeParticipantContact.contactPosition,
              };
            })()
          : getPhysicsCollisionManifold(
              createPhysicsCollisionShape(
                bodyPose(left),
                participantDimensions(left.profile),
                collisionTolerance / 2,
              ),
              createPhysicsCollisionShape(
                bodyPose(right),
                participantDimensions(right.profile),
                collisionTolerance / 2,
              ),
            );
      if (!manifold) continue;

      const result = resolveParticipantCollision(left, right, manifold);
      if (!result.collided) continue;

      participantCollisions += 1;
      estimatedImpactEnergyKj += result.impactEnergyKj;
      left.collidedWithParticipants.add(right.participant.id);
      right.collidedWithParticipants.add(left.participant.id);
      const eventId = `collision-${collisionEvents.length + 1}`;
      collisionEvents.push(
        createPhysicsCollisionEvent({
          id: eventId,
          timeSeconds: primaryImpactTime,
          type: "Participant-Participant",
          participantIds: [left.participant.id, right.participant.id],
          contactPoint: scenePosition(manifold.contactPoint, width, height),
          normal: { ...manifold.normal },
          result,
          settings,
          width,
          height,
        }),
      );
    }
  }

  if (activeParticipantContact) {
    warnings.push(
      `Continuous contact detection found the first participant collision at ${primaryImpactTime.toFixed(2)}s, before or at the authored primary marker.`,
    );
  } else if (activeObjectContact) {
    const activeObject = source.sceneObjects.find(
      (object) => object.id === activeObjectContact.objectId,
    );
    const objectLabel = activeObject?.label ?? "a scene object";
    const participantName = participants.find(
      (participant) => participant.id === activeObjectContact.participantId,
    )?.name ?? "A participant";
    const interactionKind = activeObject?.type === "Pothole"
      ? "pothole interaction"
      : activeObject && LOW_GRIP_OBJECT_TYPES.has(activeObject.type)
        ? "low-grip surface interaction"
        : "solid-object impact";
    warnings.push(
      `Continuous contact detection found ${participantName}'s first ${interactionKind} with ${objectLabel} at ${primaryImpactTime.toFixed(2)}s, before the authored primary marker.`,
    );
  } else if (participants.length > 1) {
    warnings.push(
      "No earlier participant or solid-object contact was found along the guided routes; the authored impact timing was used.",
    );
  }

  const baseFriction = surfaceFriction(source) * settings.globalFrictionMultiplier;
  const maximumSimulationTime = Math.max(source.durationSeconds, impactTime + 30);
  let simulatedDurationSeconds = impactTime;
  const interactedObjects = new Set<string>();
  let solidObjectImpacts = 0;
  let potholeInteractions = 0;
  let surfaceInteractions = 0;
  let generatedPathPoints = 0;

  const objects = source.sceneObjects.map((object) => ({
    object,
    profile: resolveSceneObjectPhysicsProfile(object),
    position: worldPosition(object.position, width, height),
    pose: sceneObjectPose(object, width, height),
  }));

  /*
   * Store the exact state where physics begins. Previously the first hidden
   * sample was not written until one simulation step later, which made
   * playback bridge from an authored route point directly to a displaced
   * post-impact body and caused a visible snap.
   */
  bodies.forEach((body) => {
    generatedPathPoints += recordPhysicsTransition(
      body,
      impactTime,
      width,
      height,
      body.primaryResponseAction ?? "Slide",
      body.primaryResponseLabel ??
        "Physics takeover after primary impact",
    );

    simulatedDurationSeconds = Math.max(
      simulatedDurationSeconds,
      impactTime,
    );
  });

  for (
    let time = impactTime + step;
    time <= maximumSimulationTime + 0.0001;
    time += step
  ) {
    bodies.forEach((body) => {
      body.previousPosition = { ...body.position };
      body.previousRotation = body.rotation;
    });

    bodies.forEach((body) => {
      if (time < body.timeSeconds || body.stopped) return;

      let localFriction = baseFriction * body.profile.rollingFriction;
      let action: MovementPathPoint["action"] =
        body.points.length === 0 && body.primaryResponseAction
          ? body.primaryResponseAction
          : "Slide";
      let label =
        body.points.length === 0 && body.primaryResponseLabel
          ? body.primaryResponseLabel
          : "Post-impact slide";
      let linkedSceneObjectId: string | undefined;

      const speed = magnitude(body.velocity);
      let nextSpeed = speed;
      if (speed > 0) {
        const direction = normalise(body.velocity);
        const estimateTravel = (friction: number) => {
          const frictionLimitedDeceleration = Math.max(
            0.35,
            9.81 * friction * 0.72,
          );
          const deceleration = Math.min(
            body.profile.brakingDecelerationMps2,
            frictionLimitedDeceleration,
          );
          const drag = speed * settings.airDrag;
          const estimatedNextSpeed = Math.max(
            0,
            speed - (deceleration + drag) * step,
          );
          const averageTravelSpeed = (speed + estimatedNextSpeed) / 2;
          return {
            nextSpeed: estimatedNextSpeed,
            end: {
              x: body.previousPosition.x + direction.x * averageTravelSpeed * step,
              y: body.previousPosition.y + direction.y * averageTravelSpeed * step,
            },
          };
        };

        const preliminaryTravel = estimateTravel(localFriction);
        objects.forEach(({ object, profile, position }) => {
          if (!profile.enabled || !LOW_GRIP_OBJECT_TYPES.has(object.type)) return;
          const interactionDistance =
            body.profile.collisionRadiusMetres + profile.collisionRadiusMetres;
          if (
            firstContactOnStep(
              body.previousPosition,
              preliminaryTravel.end,
              position,
              position,
              interactionDistance,
            )
          ) {
            localFriction *= profile.surfaceFrictionMultiplier;
          }
        });

        const travel = estimateTravel(localFriction);
        nextSpeed = travel.nextSpeed;
        body.position = travel.end;
        body.velocity = {
          x: direction.x * nextSpeed,
          y: direction.y * nextSpeed,
        };
      }

      const objectContacts = objects
        .flatMap(({ object, profile, pose }) => {
          if (!profile.enabled) return [];
          const contact = findSweptPhysicsCollision(
            bodyPose(body, true),
            bodyPose(body, false),
            participantDimensions(body.profile),
            pose,
            pose,
            objectDimensions(profile),
            profile.collidable ? collisionTolerance : 0,
          );
          return contact ? [{ object, profile, contact }] : [];
        })
        .sort((left, right) => left.contact.alpha - right.contact.alpha);

      for (const { object, profile, contact } of objectContacts) {
        body.position = { ...contact.leftPose.position };
        body.rotation = contact.leftPose.rotationDegrees;

        if (object.type === "Pothole" && !body.collidedWithObjects.has(object.id)) {
          body.velocity = rotate(
            {
              x: body.velocity.x * profile.speedLossFactor,
              y: body.velocity.y * profile.speedLossFactor,
            },
            profile.deflectionDegrees * deterministicSign(`${body.participant.id}:${object.id}`),
          );
          body.collidedWithObjects.add(object.id);
          body.angularVelocityDegreesPerSecond +=
            profile.deflectionDegrees *
            deterministicSign(`${body.participant.id}:${object.id}`) *
            2.5;
          interactedObjects.add(object.id);
          potholeInteractions += 1;
          action = "Deflect";
          label = `Deflected by ${object.label}`;
          linkedSceneObjectId = object.id;
          continue;
        }

        if (LOW_GRIP_OBJECT_TYPES.has(object.type)) {
          if (!body.collidedWithObjects.has(object.id)) {
            body.velocity = rotate(
              body.velocity,
              profile.deflectionDegrees * deterministicSign(`${object.id}:${body.participant.id}`),
            );
            body.collidedWithObjects.add(object.id);
            body.angularVelocityDegreesPerSecond +=
              profile.deflectionDegrees *
              deterministicSign(`${object.id}:${body.participant.id}`) *
              1.8;
            interactedObjects.add(object.id);
            surfaceInteractions += 1;
          }
          action = "Deflect";
          label = `Reduced grip on ${object.label}`;
          linkedSceneObjectId = object.id;
          continue;
        }

        if (SOFT_OBJECT_TYPES.has(object.type)) {
          if (!body.collidedWithObjects.has(object.id)) {
            body.velocity = rotate(
              {
                x: body.velocity.x * profile.speedLossFactor,
                y: body.velocity.y * profile.speedLossFactor,
              },
              profile.deflectionDegrees *
                deterministicSign(`${object.id}:${body.participant.id}`),
            );
            body.collidedWithObjects.add(object.id);
            body.angularVelocityDegreesPerSecond +=
              profile.deflectionDegrees *
              deterministicSign(`${object.id}:${body.participant.id}`) *
              1.2;
            interactedObjects.add(object.id);
            surfaceInteractions += 1;
          }
          action = "Deflect";
          label = `Contact with ${object.label}`;
          linkedSceneObjectId = object.id;
          continue;
        }

        if (profile.collidable && !body.collidedWithObjects.has(object.id)) {
          const result = resolveStaticObjectCollision(body, profile, contact.manifold);
          if (!result.collided) continue;
          body.position = {
            x: body.position.x - contact.manifold.normal.x * contact.manifold.penetrationMetres,
            y: body.position.y - contact.manifold.normal.y * contact.manifold.penetrationMetres,
          };
          body.collidedWithObjects.add(object.id);
          interactedObjects.add(object.id);
          solidObjectImpacts += 1;
          estimatedImpactEnergyKj += result.impactEnergyKj;
          const eventId = `collision-${collisionEvents.length + 1}`;
          collisionEvents.push(
            createPhysicsCollisionEvent({
              id: eventId,
              timeSeconds: time - step + step * contact.alpha,
              type: "Participant-Object",
              participantIds: [body.participant.id],
              sceneObjectId: object.id,
              contactPoint: scenePosition(
                contact.manifold.contactPoint,
                width,
                height,
              ),
              normal: { ...contact.manifold.normal },
              result,
              settings,
              width,
              height,
            }),
          );

          const exactObjectContactTime =
            time -
            step +
            step * contact.alpha;

          generatedPathPoints +=
            recordPhysicsTransition(
              body,
              exactObjectContactTime,
              width,
              height,
              "Ricochet",
              `Impact with ${object.label}`,
              object.id,
            );

          simulatedDurationSeconds = Math.max(
            simulatedDurationSeconds,
            exactObjectContactTime,
          );
          action = "Ricochet";
          label = `Impact with ${object.label}`;
          linkedSceneObjectId = object.id;
          break;
        }
      }

      stabiliseBodyAngularVelocity(body);

      body.rotation += body.angularVelocityDegreesPerSecond * step;
      body.angularVelocityDegreesPerSecond *= Math.exp(
        -(1.15 + body.profile.lateralGrip * 1.9) * step,
      );
      const travelHeading = rotationFromVelocity(body.velocity, body.rotation);
      body.rotation = blendRotation(
        body.rotation,
        travelHeading,
        body.profile.lateralGrip * step * 1.35,
      );

      if (body.position.x < 0 || body.position.x > width) {
        body.position.x = clamp(body.position.x, 0, width);
        body.velocity.x *= -0.22;
        body.angularVelocityDegreesPerSecond +=
          deterministicSign(`${body.participant.id}:edge-x`) * 55;
        action = "Ricochet";
        label = "Scene-edge deflection";
      }
      if (body.position.y < 0 || body.position.y > height) {
        body.position.y = clamp(body.position.y, 0, height);
        body.velocity.y *= -0.22;
        body.angularVelocityDegreesPerSecond +=
          deterministicSign(`${body.participant.id}:edge-y`) * 55;
        action = "Ricochet";
        label = "Scene-edge deflection";
      }

      const reachedStop =
        nextSpeed <= 0.01 ||
        mpsToKmh(magnitude(body.velocity)) <= settings.stopSpeedKmh;
      if (reachedStop) {
        body.velocity = { x: 0, y: 0 };
        body.angularVelocityDegreesPerSecond = 0;
        action = "Stop";
        label = "Natural rest position";
      }

      const shouldRecord =
        body.points.length === 0 ||
        (["Ricochet", "Deflect"] as string[]).includes(action) ||
        reachedStop ||
        Math.round((time - impactTime) / step) % Math.max(1, Math.round(0.4 / step)) === 0;

      if (shouldRecord) {
        body.points.push(
          makePhysicsPoint(
            body,
            time,
            scenePosition(body.position, width, height),
            action,
            label,
            linkedSceneObjectId,
          ),
        );
        generatedPathPoints += 1;
        simulatedDurationSeconds = Math.max(simulatedDurationSeconds, time);
      }

      if (reachedStop) {
        body.stopped = true;
        body.restTimeSeconds ??= time;
      }
    });

    for (let leftIndex = 0; leftIndex < bodies.length; leftIndex += 1) {
      for (let rightIndex = leftIndex + 1; rightIndex < bodies.length; rightIndex += 1) {
        const left = bodies[leftIndex];
        const right = bodies[rightIndex];
        if (left.collidedWithParticipants.has(right.participant.id)) continue;

        const contact = findSweptPhysicsCollision(
          bodyPose(left, true),
          bodyPose(left, false),
          participantDimensions(left.profile),
          bodyPose(right, true),
          bodyPose(right, false),
          participantDimensions(right.profile),
          collisionTolerance,
        );
        if (!contact) continue;

        left.position = { ...contact.leftPose.position };
        left.rotation = contact.leftPose.rotationDegrees;
        right.position = { ...contact.rightPose.position };
        right.rotation = contact.rightPose.rotationDegrees;
        left.stopped = false;
        right.stopped = false;
        left.restTimeSeconds = undefined;
        right.restTimeSeconds = undefined;
        const result = resolveParticipantCollision(left, right, contact.manifold);
        if (!result.collided) continue;

        const totalMass = left.profile.massKg + right.profile.massKg;
        left.position = {
          x:
            left.position.x -
            contact.manifold.normal.x *
              contact.manifold.penetrationMetres *
              (right.profile.massKg / totalMass),
          y:
            left.position.y -
            contact.manifold.normal.y *
              contact.manifold.penetrationMetres *
              (right.profile.massKg / totalMass),
        };
        right.position = {
          x:
            right.position.x +
            contact.manifold.normal.x *
              contact.manifold.penetrationMetres *
              (left.profile.massKg / totalMass),
          y:
            right.position.y +
            contact.manifold.normal.y *
              contact.manifold.penetrationMetres *
              (left.profile.massKg / totalMass),
        };
        left.collidedWithParticipants.add(right.participant.id);
        right.collidedWithParticipants.add(left.participant.id);
        participantCollisions += 1;
        estimatedImpactEnergyKj += result.impactEnergyKj;
        const contactTime = time - step + step * contact.alpha;
        const eventId = `collision-${collisionEvents.length + 1}`;
        collisionEvents.push(
          createPhysicsCollisionEvent({
            id: eventId,
            timeSeconds: contactTime,
            type: "Participant-Participant",
            participantIds: [left.participant.id, right.participant.id],
            contactPoint: scenePosition(
              contact.manifold.contactPoint,
              width,
              height,
            ),
            normal: { ...contact.manifold.normal },
            result,
            settings,
            width,
            height,
          }),
        );

        /*
         * The integration loop may already have recorded a sample at "time"
         * before swept contact resolution rewound both bodies to contactTime.
         * Replace that stale sample with corrected post-impulse states for both
         * participants at the exact same timestamp.
         */
        generatedPathPoints +=
          recordPhysicsTransition(
            left,
            contactTime,
            width,
            height,
            left.primaryResponseAction ??
              "Deflect",
            left.primaryResponseLabel ??
              `Post-impact response after contact with ${right.participant.name}`,
          );

        generatedPathPoints +=
          recordPhysicsTransition(
            right,
            contactTime,
            width,
            height,
            right.primaryResponseAction ??
              "Deflect",
            right.primaryResponseLabel ??
              `Post-impact response after contact with ${left.participant.name}`,
          );

        // The collision event is the authoritative impact record. Do not
        // manufacture route diamonds at the contact point; post-impact motion
        // samples begin on the next simulation step and remain internal.
        simulatedDurationSeconds = Math.max(simulatedDurationSeconds, contactTime);
      }
    }

    bodies.forEach((body) => {
      const previousSample = body.trajectorySamples.at(-1);
      const moved =
        !previousSample ||
        vectorMagnitude(
          subtractVector(body.position, previousSample.position),
        ) > 0.00001;
      const velocityChanged =
        !previousSample ||
        vectorMagnitude(
          subtractVector(body.velocity, previousSample.velocity),
        ) > 0.00001;
      const rotationChanged =
        !previousSample ||
        Math.abs(
          body.angularVelocityDegreesPerSecond -
            previousSample.angularVelocityDegreesPerSecond,
        ) > 0.00001;

      if (moved || velocityChanged || rotationChanged || body.stopped) {
        body.trajectorySamples.push({
          timeSeconds: time,
          position: { ...body.position },
          velocity: { ...body.velocity },
          angularVelocityDegreesPerSecond:
            body.angularVelocityDegreesPerSecond,
        });
      }
    });

    if (bodies.length > 0 && bodies.every((body) => body.stopped)) break;
  }

  const updatedVehicles = source.vehicles.map((participant) => {
    const body = bodies.find(
      (candidate) =>
        candidate.participant.id === participant.id,
    );

    const authoredPoints = sortMovementPathPoints(
      participant.pathPoints,
    ).filter(
      (point) => !isPhysicsGeneratedPathPoint(point),
    );

    if (!body || body.points.length === 0) {
      return syncLegacyParticipantFields({
        ...participant,
        physics: resolveParticipantPhysicsProfile(participant),
        pathPoints: authoredPoints,
      });
    }

    const internalPhysicsPoints = body.points.filter(
      (point) =>
        point.timeSeconds >= impactTime - 0.0001,
    );

    // Preserve every investigator-created point at its original position.
    // Physics samples are appended only as hidden playback data; they never
    // replace, relocate or duplicate Point 1, intermediate points or Point Z.
    const pathPoints = sortMovementPathPoints([
      ...authoredPoints,
      ...internalPhysicsPoints,
    ]);

    return syncLegacyParticipantFields({
      ...participant,
      physics: body.profile,
      pathPoints,
    });
  });

  collisionEvents.forEach((event) => {
    if (!event.kinematics) return;

    event.kinematics = enrichCollisionKinematicsWithTravel({
      kinematics: event.kinematics,
      bodies,
      width,
      height,
    });
  });

  if (participantCollisions === 0 && participants.length > 1) {
    warnings.push(
      "No participant-to-participant collision impulse was produced. Check that Impact points and times converge at the primary collision marker.",
    );
  }
  if (!source.collisionSetup?.confirmed) {
    warnings.push("The primary collision point has not been confirmed by the officer.");
  }
  if (bodies.some((body) => !body.stopped)) {
    warnings.push(
      "At least one participant reached the simulation safety limit before settling; review its final path and scene dimensions.",
    );
  }
  warnings.push(
    "This is a deterministic planning simulation, not a certified forensic or crash-dynamics calculation.",
  );

  const firstCollisionEvent = [...collisionEvents].sort(
    (left, right) =>
      left.timeSeconds - right.timeSeconds,
  )[0];
  const firstParticipantCollisionEvent = collisionEvents
    .filter(
      (event) =>
        event.type === "Participant-Participant",
    )
    .sort(
      (left, right) =>
        left.timeSeconds - right.timeSeconds,
    )[0];

  const primaryCollisionKinematics =
    firstParticipantCollisionEvent?.kinematics ??
    firstCollisionEvent?.kinematics;
  const participantKinematics =
    primaryCollisionKinematics?.participants ?? [];
  const totalIncomingKineticEnergyKj =
    primaryCollisionKinematics?.totalIncomingKineticEnergyKj ?? 0;
  const totalOutgoingKineticEnergyKj =
    primaryCollisionKinematics?.totalOutgoingKineticEnergyKj ?? 0;
  const totalDissipatedKineticEnergyKj =
    primaryCollisionKinematics?.dissipatedKineticEnergyKj ?? 0;
  const totalPostImpactTravelDistanceMetres =
    participantKinematics.reduce(
      (sum, participant) =>
        sum + participant.postImpactTravelDistanceMetres,
      0,
    );

  if (primaryCollisionKinematics) {
    warnings.push(
      `Average collision force is an estimate based on an assumed ${primaryCollisionKinematics.assumedContactDurationRangeMs.minimum.toFixed(0)}–${primaryCollisionKinematics.assumedContactDurationRangeMs.maximum.toFixed(0)} ms contact duration. Impulse is the more direct solver output.`,
    );
  }

  if (firstParticipantCollisionEvent) {
    const horizontalOffsetMetres =
      ((firstParticipantCollisionEvent.contactPoint.x -
        source.collisionPoint.x) /
        100) *
      width;
    const verticalOffsetMetres =
      ((firstParticipantCollisionEvent.contactPoint.y -
        source.collisionPoint.y) /
        100) *
      height;
    const markerOffsetMetres = Math.hypot(
      horizontalOffsetMetres,
      verticalOffsetMetres,
    );

    if (markerOffsetMetres > Math.max(0.35, collisionTolerance * 2)) {
      warnings.push(
        `The first participant contact occurred ${markerOffsetMetres.toFixed(2)} m from the centre of the primary collision marker. The marker is visual only; adjust the routes or marker if the intended contact should occur at its centre.`,
      );
    }
  }

  const summary: PhysicsSimulationSummary = {
    solverVersion: "RoadSafe Physics V2",
    dynamicsEngine: "RoadSafe Legacy 2D",
    dynamicsEngineVersion: "RoadSafe Physics V2",
    ranAt: new Date().toISOString(),
    participantCollisions,
    primaryImpactTimeSeconds:
      firstCollisionEvent?.timeSeconds ??
      primaryImpactTime,
    estimatedImpactEnergyKj: Number(estimatedImpactEnergyKj.toFixed(1)),
    solidObjectImpacts,
    potholeInteractions,
    surfaceInteractions,
    generatedPathPoints,
    simulatedDurationSeconds: ceilSimulationTime(simulatedDurationSeconds),
    collisionEvents,
    primaryCollisionKinematics,
    participantKinematics,
    totalIncomingKineticEnergyKj: roundPhysicsValue(
      totalIncomingKineticEnergyKj,
    ),
    totalOutgoingKineticEnergyKj: roundPhysicsValue(
      totalOutgoingKineticEnergyKj,
    ),
    totalDissipatedKineticEnergyKj: roundPhysicsValue(
      totalDissipatedKineticEnergyKj,
    ),
    totalPostImpactTravelDistanceMetres: roundPhysicsValue(
      totalPostImpactTravelDistanceMetres,
      2,
    ),
    estimatedAverageForceRangeKn:
      primaryCollisionKinematics?.estimatedAverageForceRangeKn,
    warnings,
  };

  const collisionTimelineEvents = collisionEvents.map((event) => {
    const participantNames = event.participantIds.map(
      (participantId) =>
        source.vehicles.find((participant) => participant.id === participantId)?.name ??
        "Participant",
    );
    const objectLabel = event.sceneObjectId
      ? source.sceneObjects.find((object) => object.id === event.sceneObjectId)?.label
      : undefined;

    return {
      id: createId("physics-event"),
      timeSeconds: event.timeSeconds,
      title:
        event.type === "Participant-Participant"
          ? `${participantNames.join(" ↔ ")}: physical contact`
          : `${participantNames[0]}: contact with ${objectLabel ?? "scene object"}`,
      description: event.kinematics
        ? `${event.relativeSpeedKmh.toFixed(1)} km/h relative speed · ${event.totalImpulseNs.toFixed(0)} N·s impulse · ${event.kinematics.dissipatedKineticEnergyKj.toFixed(1)} kJ dissipated kinetic energy · ${event.estimatedAverageForceRangeKn.minimum.toFixed(1)}–${event.estimatedAverageForceRangeKn.maximum.toFixed(1)} kN estimated average force.`
        : `${event.relativeSpeedKmh.toFixed(1)} km/h relative speed · ${event.estimatedEnergyKj.toFixed(1)} kJ estimated energy.`,
      type: "Collision" as const,
      participantId: event.participantIds[0],
      sceneObjectId: event.sceneObjectId,
    };
  });

  const generatedMotionTimelineEvents = updatedVehicles.flatMap((participant) =>
    participant.pathPoints
      .filter(
        (point) =>
          isPhysicsGeneratedPathPoint(point) &&
          ["Ricochet", "Deflect", "Stop"].includes(point.action),
      )
      .map((point) => ({
        id: createId("physics-event"),
        timeSeconds: point.timeSeconds,
        title: `${participant.name}: ${point.label}`,
        description: point.notes ?? "Physics-generated movement result.",
        type:
          point.action === "Ricochet"
            ? ("Collision" as const)
            : ("Participant Action" as const),
        participantId: participant.id,
        sceneObjectId: point.linkedSceneObjectId,
      })),
  );

  const generatedTimelineEvents = [
    ...collisionTimelineEvents,
    ...generatedMotionTimelineEvents,
  ];

  const preservedTimeline = source.timelineEvents.filter(
    (event) => !event.id.startsWith("physics-event"),
  );

  const result: AccidentReconstruction = {
    ...source,
    collisionPoint: { ...source.collisionPoint },
    durationSeconds:
      ceilSimulationTime(
        Math.max(
          source.durationSeconds,
          simulatedDurationSeconds,
        ),
      ),
    vehicles: updatedVehicles,
    sceneObjects: source.sceneObjects.map((object) => ({
      ...object,
      physics: resolveSceneObjectPhysicsProfile(object),
    })),
    physicsSettings: settings,
    lastPhysicsSimulation: summary,
    timelineEvents: [...preservedTimeline, ...generatedTimelineEvents],
  };

  playbackPhysicsSignatureCache.set(
    result.id,
    createPlaybackPhysicsSignature(result),
  );
  return result;
}
